#!/usr/bin/perl
# $Id: BNG2.pl,v 1.5 2005/11/08 16:41:35 faeder Exp $

use FindBin;
use lib $FindBin::Bin;
use BNGModel;
use SpeciesList;
use BNGUtils;
use strict;

# turn off output buffering on STDOUT
#(select(*STDOUT), $|=1)[0];

#printf "BioNetGen version %s\n", BNGversion();
 
#$model= BNGModel->new();
my ($a, $b, $c);

my $s= \"111";

print $$s,"\n";
