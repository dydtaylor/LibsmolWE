#!/usr/bin/perl

# doesn't work
for $i (10..1){
  print "$i\n";
}
